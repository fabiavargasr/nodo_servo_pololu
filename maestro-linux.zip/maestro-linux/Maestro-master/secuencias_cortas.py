# Sequence 0  antiohorario
begin
  500 0 0 6050 0 0 0 frame_0..5 # Frame 0
  50 6843 frame_2 # Frame 1
  500 6033 frame_2 # Frame 2
repeat

sub frame_0..5
  5 servo
  4 servo
  3 servo
  2 servo
  1 servo
  0 servo
  delay
  return

sub frame_2
  2 servo
  delay
  return



# sentido horario


### Sequence subroutines: ###

# Sequence 0
sub Sequence_0
  500 0 0 6083 0 0 0 frame_0..5 # Frame 0
  20 5554 frame_2 # Frame 1
  500 6050 frame_2 # Frame 2
  return

sub frame_0..5
  5 servo
  4 servo
  3 servo
  2 servo
  1 servo
  0 servo
  delay
  return

sub frame_2
  2 servo
  delay
  return
