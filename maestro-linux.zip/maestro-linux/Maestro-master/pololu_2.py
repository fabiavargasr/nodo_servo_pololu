




#!/usr/bin/env python
# -*- coding: utf-8 -*-


import maestro
import time

#define servo
servo = maestro.Controller(ttyStr='/dev/ttyS1')
min_imp=900
max_imp=2000
step_imp=100

if __name__ == '__main__' :
    #infinite loop
    while 1:
          #user input
  #        msg=raw_input("Enter servo id and command: YxZZZZ:  \n")

          #convert msg into id and cmd
  #        sep=msg.find("x")
          m1=1
          m2=1800
          servoId=int(m1)
          servoCmd=int(m2)

          #saturate input
          servoId=min(max(0,servoId),6);
          servoCmd=min(max(min_imp,servoCmd),max_imp);

          print(m1)
          print("servoId : {}    servoCmd : {} \n".format(servoId,servoCmd))

          servo.setTarget(servoId,servoCmd)
          time.sleep(0.1)

    servo.close





# import maestro
# import time

# servo = maestro.Controller()
# servo.setAccel(1,1)      #set servo 0 acceleration to 4
# servo.setTarget(0,1800)  #set servo to move to center position
# servo.setSpeed(1,10)     #set speed of servo 1
# #x = servo.getPosition(1) #get the current position of servo 1



# time.sleep(5)



# servo.close()



#sudo chmod 666 /dev/ttyACM0  