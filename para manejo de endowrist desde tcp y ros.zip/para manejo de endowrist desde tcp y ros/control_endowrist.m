
clc

clear all
close all

%% enlace tcp para motor

    t = tcpip('192.168.1.100', 50003);
    
    fopen(t);
  
    
serverdata='inicio';
fwrite(t, serverdata);
%%  4.     trayectoria circular sentido reloj  GGGGGGIIIIII

%toc

serverdata='giroh';
fwrite(t, serverdata);


%%  9.  trayectoria anti hora   IIIIIINNNNNNNVVVVVV
%toc
% giro invertido va despues de haber enviado giroh
serverdata='giroh_inv';
fwrite(t, serverdata);
%%  5  posicion inicial para el movimiento PARA PREPARAR EL PROXIMO

serverdata='inicio';
fwrite(t, serverdata);
%% 6. control servo
serverdata='abrir';
fwrite(t, serverdata);



%% 7. control servo
serverdata='cerrar';
fwrite(t, serverdata);


%% 8. control servo
serverdata='inicio';
fwrite(t, serverdata);

%% control servo
serverdata='descanso';
fwrite(t, serverdata);




%% control servo
serverdata='salir';
fwrite(t, serverdata);

clearvars t