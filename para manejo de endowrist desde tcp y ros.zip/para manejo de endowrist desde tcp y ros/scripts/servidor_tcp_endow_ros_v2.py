

#!/usr/bin/env python

# Echo server program

# este programa permite recibir desde matlab comandos tcp con los cuales se publica
# posiciones para el nodo de servomotores
# si el puerto no se cierra hay que cambiarlo


# v2 tiene cierre pinza_ y abrir pinza
# ademas inicio con tiempo
import socket
import rospy  #importar rospy
from std_msgs.msg import Int16 
import numpy as np
import time
import re 



HOST = '192.168.1.100'
PORT = 50002

global pos_motor_roll 
global pos_motor_yaw


pos_motor_roll=0


s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.listen(1)
print "waiting for response from client at port ",PORT
conn, addr = s.accept()
print 'Connected by', addr
print 'servidor arriba y conectado'




# subscriptores
def  callback_function_1(data): #funcion a la que se llama cuando recibo un mensaje en el topic al que nos subscribimos
   # rospy.loginfo("He recibido: %s y %f", data.stamp, data.num) #escribe en el log el mensaje recibido
    global pos_motor_roll 
    valor=str(data)
    valor1 = [float(s) for s in re.findall(r'-?\d+\.?\d*', valor)]
    
    
   # print("Posicion motor 1 roll es", valor1[0],"de tipo",type(valor1[0]))
  
    pos_motor_roll=valor1[0]
    #pos_motor_roll=data.Int16
    #return pos_motor_roll

def callback_function_4(data): #funcion a la que se llama cuando recibo un mensaje en el topic al que nos subscribimos
    global pos_motor_yaw 
    valor=str(data)
    valor1 = [float(s) for s in re.findall(r'-?\d+\.?\d*', valor)]
    pos_motor_yaw=valor1[0]



rospy.Subscriber("/EndoWrist/servoOne/pos", Int16, callback_function_1)
rospy.Subscriber("/EndoWrist/servoFour/pos", Int16, callback_function_4)




roll = rospy.Publisher('/EndoWrist/servo1/target', Int16, queue_size=10) #crea el publicador en el topic hola_mundo y tipo de mensaje int16

yaw = rospy.Publisher('/EndoWrist/servo4/target', Int16, queue_size=10)
pitch_1 = rospy.Publisher('/EndoWrist/servo2/target', Int16, queue_size=10)
pitch_2 = rospy.Publisher('/EndoWrist/servo3/target', Int16, queue_size=10)

rospy.init_node('publicador', anonymous=True) #inicia el nodo publicador
rate = rospy.Rate(0.5) # 0.5 Hz

rospy.loginfo("Estoy publicando en el topic hola_mundo") #escribo en log


lstr=1000
a = np.int16(lstr)
roll.publish(a)

lstr=1500
a = np.int16(lstr)
pitch_1.publish(a)
 
lstr=1500
a = np.int16(lstr)
pitch_2.publish(a)
 
 
lstr=1666
a = np.int16(lstr)
yaw.publish(a)



# variables para cerrar y abrir

paso=50

cant_pasos=16

p_inicial=1008



while True:
    data = conn.recv(1024)
    print data
    
    
    valor = [float(s) for s in re.findall(r'-?\d+\.?\d*', data)]  
    ind_cad=data.find('opt')
 



    
    
    if ind_cad!=-1:
        
        print("el valor es ",valor[0])
        
    
        lstr = int(valor[0])
        a = np.int16(lstr)
        roll.publish(a)
  
    
    
    

    
    # if data=="ty2":
        # print("tray cir")
    
        # tt=0.1
        # pasos=5
        # pasos_y=8
        
        # p_inicial=1000
        # p_ini_ya=1375
        
        
        # lstr = p_inicial
        # a = np.int16(lstr)
        # roll.publish(a)
       
        # lstr_2=1666
        # a = np.int16(lstr_2)
        # yaw.publish(a)
               
        # time.sleep(tt)
        
        # p_roll=p_inicial
        # p_y=p_ini_ya
        
        # a = np.int16(p_y)
        # pitch_1.publish(a)
        # pitch_2.publish(a)
            
        
        
        # # los pasos da la velocidad si el num es pequeno mas lento
        # # el rango del ciclo establece la cantidad de grados que gira
        # for ind in range(29):
        
            # p_roll = p_roll+33
            # b = np.int16(p_roll)
            # roll.publish(b)

            # # p_y=p_y-5
            
            # # a = np.int16(p_y)
            # # pitch_1.publish(a)
            # # pitch_2.publish(a)
            
            
            # time.sleep(tt)            
    
    
    
    
    
    
    
    # if data=="circular":
        # print("tray cir")
    
        # tt=0.051
        # pasos=5
        # pasos_y=8
        
        # p_inicial=1000
        # p_ini_ya=1500
        
        
        # lstr = p_inicial
        # a = np.int16(lstr)
        # roll.publish(a)
        # time.sleep(tt)
        
        # lstr_2=p_ini_ya
        # a = np.int16(lstr_2)
        # yaw.publish(a)
               
        
        
        
        # # los pasos da la velocidad si el num es pequeno mas lento
        # # el rango del ciclo establece la cantidad de grados que gira
        # for ind in range(32):
            # lstr = lstr+pasos
            # b = np.int16(lstr)
            # roll.publish(b)

            
            # lstr_2=lstr_2+pasos_y
            
            # a = np.int16(lstr_2)
            # yaw.publish(a)
            
            # time.sleep(tt)        
    
    
    # tiempo de giro
    
    tt=0.0830
    
    if data=="giroh":
        tm1=time.time()
        print("girando")
    
        
       # pasos=50
   #     p_inicial=1129
     #   cant_pasos=18
        
        lstr = p_inicial
        a = np.int16(lstr)
        roll.publish(a)
        time.sleep(tt)
        # los pasos da la velocidad
        # el rango del ciclo establece la cantidad de grados que gira
        # si los pasos son mas grandes aumenta la velocidad, 
        #  hacer el analisis 1129+pasos*cant_pasos< 2000
        for ind in range(cant_pasos):
            
            
            lstr = lstr+paso
            a = np.int16(lstr)
            roll.publish(a)
            time.sleep(tt)
        elapsed=time.time()-tm1 
        print  elapsed
   #  funcion que devuelve algun dato
     #   conn.send(patron)   

    
    if data=="giroh_inv":
        #tm1=time.time()
       # print("girando")
    
       # pasos=50
   #     p_inicial=1129
     #   cant_pasos=18
        

        # los pasos da la velocidad
        # el rango del ciclo establece la cantidad de grados que gira
        # si los pasos son mas grandes aumenta la velocidad, 
        #  hacer el analisis 1129+pasos*cant_pasos< 2000
        for ind in range(cant_pasos):
            
            
            lstr = lstr-paso
            a = np.int16(lstr)
            roll.publish(a)
            time.sleep(tt)
        #elapsed=time.time()-tm1 
        print  elapsed
   #  funcion que devuelve algun dato
     #   conn.send(patron)   




    
    
    if data=="inicio_t":
        tm1=time.time()
        print("girando")
    
        tt=0.1
      #  pasos=50
        p_inicial=2000
       # cant_pasos=18
        
        lstr = p_inicial
        #a = np.int16(lstr)
        #roll.publish(a)
       # time.sleep(tt)
        # los pasos da la velocidad
        # el rango del ciclo establece la cantidad de grados que gira
        # si los pasos son mas grandes aumenta la velocidad, 
        #  hacer el analisis 1129+pasos*cant_pasos< 2000
        for ind in range(cant_pasos):
            
            
            lstr = lstr-pasos
            a = np.int16(lstr)
            roll.publish(a)
            time.sleep(tt)
      #  elapsed=time.time()-tm1 
        #print  elapsed





    if data=="abrir":
        print("abrir pinza")
    
        
        lstr = 960
        a = np.int16(lstr)
        pitch_1.publish(a)


        lstr = 1240
        a = np.int16(lstr)
        pitch_2.publish(a)
        time.sleep(5)

      




    if data=="cerrar":


        lstr = 1780
        #lstr = 1580
       
	a = np.int16(lstr)
        pitch_1.publish(a)


        lstr = 1240
       # lstr = 1040
        a = np.int16(lstr)
        pitch_2.publish(a)
        time.sleep(5)

    if data=="descanso":


        lstr = 1490
        a = np.int16(lstr)
        pitch_1.publish(a)


        lstr = 1438
        a = np.int16(lstr)
        pitch_2.publish(a)
        time.sleep(5)


 
    if data=="inicio":
        print("ir a inicio")
 
        a = np.int16(p_inicial)
        roll.publish(a)
       


        
    if data=="recibir":
        print("ir a recibir")
   	p_recibir=1700
        a = np.int16(p_recibir)
        roll.publish(a)
        time.sleep(1)
 
        
    # if data=="inicio_rep":
        # print("ir a inicio")
    
        # tt=0.1
        # pasos=50
        # p_inicial=1000
        # p_inicial_ya=1500     

        # dif=pos_motor_roll-p_inicial
        
        # print("dif Posicion motor 1 roll es", dif)     
        
        # while dif > 50:
            
            # dif=pos_motor_roll-p_inicial
            # pos_motor=pos_motor_roll-pasos
            
            # print("ir a inicio",pos_motor)
            # a = np.int16(pos_motor)
            # roll.publish(a)
            # time.sleep(tt)
            
        # if pos_motor_yaw >  1500:

            # dif=pos_motor_yaw-p_inicial_ya
            # while dif > 50:
                
                # dif=pos_motor_yaw-p_inicial_ya
                # pos_motor=pos_motor_yaw-pasos
                
                # print("ir a inicio",pos_motor)
                # a = np.int16(pos_motor)
                # roll.publish(a)
                # time.sleep(tt)



        # if pos_motor_yaw <  1500:

            # dif=p_inicial_ya-pos_motor_yaw
            # while dif > 50:
                
                # dif=p_inicial_ya-pos_motor_yaw
                # pos_motor=pos_motor_yaw+pasos
                
                # print("ir a inicio",pos_motor)
                # a = np.int16(pos_motor)
                # roll.publish(a)
                # time.sleep(tt)





        
       #   conn.send(list2str)
	 
    if data=="salir":
        print("saliendo")
        clientdata="terminando"
        conn.sendall(clientdata)
        break
	 
 
 
	 
conn.close()

